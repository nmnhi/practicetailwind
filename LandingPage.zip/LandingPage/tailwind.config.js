/** @type {import('tailwindcss').Config} */
module.exports = {
  mode: "jit",
  content: ["./public/index.html"],
  // purge: ["./public/*.html", "./public/*.js", "/public/index.html"],
  theme: {
    extend: {
      height: {
        custom: "620px",
      },
      spacing: {
        "40-c": "40rem",
      },
    },
  },
  plugins: [],
};
